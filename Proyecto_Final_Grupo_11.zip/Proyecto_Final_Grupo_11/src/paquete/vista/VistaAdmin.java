package paquete.vista;

import paquete.tdas.*;
import javax.swing.JFrame;

public class VistaAdmin {
    private static final Pila<JFrame> pila = new Pila<>();
    
    public static void abrirNuevaVista(JFrame vistaActual, JFrame vistaNueva)
    {
        vistaActual.setVisible(false);
        pila.apilar(vistaActual);
        vistaNueva.setVisible(true);
    }
    
    public static void atras(JFrame vistaActual)
    {
        vistaActual.dispose();
        pila.desapilar().setVisible(true);
    }
}
