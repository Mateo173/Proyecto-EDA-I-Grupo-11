package paquete.tdas;

public class Pila<T> {

    // Atributos

    private Nodo<T> cima;

    // Constructor para crear una pila
    public Pila() { // objeto pila totalmente vacia
        cima = null;
    }

    // Otro metodos
    // Verifica si una pila esta vacia

    public boolean esVacia() {
        return cima == null;
    }

    // push() - Apilar: Añade un elemento en la cima de la pila

    public void apilar(T item) {
        Nodo<T> nuevoNodo = new Nodo<>(item, null);
        if (esVacia()) {
            cima = nuevoNodo;
        } else { // la pila no esta vacia
            Nodo<T> aux = cima;
            nuevoNodo.setSgteNodo(aux);
            cima = nuevoNodo;
        }
    }

    // pop() - desapilar: Sacar un elemento de la pila
    public T desapilar() {
        if (!esVacia()) {
            // eliminar el nodo de la cima
            T item = cima.getItem();
            cima = cima.getSgteNodo();
            return item;
        } else {
            throw new RuntimeException("La pila esta vacia!!");
        }

    }

    public T cima() {
        if (!esVacia()) {
            return cima.getItem();
        } else {
            throw new RuntimeException("ERROR: no es posible devolver cima");
        }
    }

    public int longitud() {
        int i = 0;
        Nodo<T> aux = cima;
        while (aux != null) {
            aux = aux.getSgteNodo();
            i++;
        }
        return i;
    }
}

