package paquete.data.admin;

import paquete.data.clases.Expediente;
import paquete.data.clases.UsuarioData;
import paquete.tdas.*;
import java.time.LocalDate;
import paquete.data.clases.Oficina;
import java.lang.Iterable;

public class UsuarioAdmin {
    private static ListaSimpleEnlazada<UsuarioData> usuarios = new ListaSimpleEnlazada<>();
    private static ListaDobleEnlazada<Expediente> expedientes = new ListaDobleEnlazada<>();
    private static ListaSimpleEnlazada<Oficina> oficinas = new ListaSimpleEnlazada<>();
    
    public static void crear()
    {
        UsuarioData usuario = new UsuarioData("admin", "123");
        usuarios.agregar(usuario);
        
        //System.out.println("Usuario administrador agregado");
    }
    
    public static void crearOficina()
    {
        Oficina oficina1 = new Oficina("Oficina1");
        Oficina oficina2 = new Oficina("Oficina2");
        Oficina oficina3 = new Oficina("Oficina3");
        Oficina oficinaAdmin = new Oficina("Admin");
        oficinas.agregar(oficina1);
        oficinas.agregar(oficina2);
        oficinas.agregar(oficina3);
        oficinas.agregar(oficinaAdmin);
        
    }
    
    public static ListaSimpleEnlazada<UsuarioData> usuarios()
    {
        return usuarios;
    }
    
    public static ListaSimpleEnlazada<Oficina> oficinas()
    {
        return oficinas;
    }
    
    public static ListaDobleEnlazada<Expediente> expedientes()
    {
        return expedientes;
    }
    
    public static void añadirUsuario(UsuarioData usuarioData)
    {
        usuarios.agregar(usuarioData);
    }
    
    public static void registrarExpediente(Expediente expediente)
    {
        expedientes.agregar(expediente);
        expediente.sinFecha();
        expediente.inicioTramite();
    }
    
    public static void agregarExpedienteAdmin(Expediente expediente, Oficina admin)
    {
        admin.recibirExpediente(expediente);
    }
    
    public static void registrarMovimiento(Expediente expediente, Oficina org, Oficina dest, String doc)
    {
        EventoSeguimiento evento = new EventoSeguimiento(org, dest,doc );
        evento.setFecha(LocalDate.now());
        expediente.eventos.agregar(evento);
        expediente.agregarDoc(doc);
        org.derivarExpediente(expediente, dest);
        dest.recibirExpediente(expediente);
    }
    
    public static void finalizarExpediente(Expediente expediente)
    {
        expediente.finalizarTramite();
    }
    
    
    public static Expediente buscarExpediente(String id)
    {
        //String id = expediente.getExp_id();
        
        for (int i = 1; i <= expedientes.longitud(); i++) {
            Expediente aux = expedientes.iesimo(i);
            if (aux != null && id.equals(aux.getExp_id()))
            {
                //System.out.println("Entro");
                return aux;
            }
        }
        return null;
    }
    
    public static Oficina buscarExpedienteOficina(String id)
    {
        Oficina actual = new Oficina();
        for (int i = 1; i <= oficinas.longitud(); i++) {
            Oficina aux = oficinas.iesimo(i);
            Cola<Expediente> aux2 = new Cola<>();
            while (!aux.cola.esVacia())
            {
                Expediente expedienteAux = aux.cola.desencolar();
                //System.out.println("nombre ofi: " + aux.getNombre());
                //System.out.println("id a buscar: " + id);
                //System.out.println("id expediente: " + expedienteAux.getExp_id());
                if (id.equals(expedienteAux.getExp_id()))
                {
                    //System.out.println(aux.getNombre());
                    actual = aux;
                }
                aux2.encolar(expedienteAux);
            }
            
            while (!aux2.esVacia())
            {
                aux.cola.encolar(aux2.desencolar());
            }
        }
        return actual;
    }
    
    
    public static Oficina buscarOficina(String nombre)
    {
        //System.out.println("Logitud: " + oficinas.longitud());
        for (int i = 1; i <= oficinas.longitud(); i++) {
            //System.out.println("Parametro nombre: " + nombre);
            Oficina aux = oficinas.iesimo(i);
            //System.out.println("Nombre: " + aux.getNombre());
            //System.out.println(i);
            if (aux != null && nombre.equals(aux.getNombre()))
            {
                return aux;
            }
        }
        return null;
    }
    
    public static void agregarDoc(Expediente expediente, String doc)
    {
        expediente.agregarDoc(doc);
    }
    
    public static void generarEstado(Expediente expediente)
    {
        LocalDate sinFecha = LocalDate.of(0000,1,01);
        if (sinFecha.equals(expediente.getFechaFin()))
        {
            expediente.setEstado("En tramite");
        }
        else
        {
            expediente.setEstado("Finalizado");
        }
        
    }
}
