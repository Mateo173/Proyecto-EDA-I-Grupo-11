package paquete.data.admin;

import java.time.LocalDate;
import paquete.data.clases.Expediente;
import paquete.data.clases.Oficina;

public class EventoSeguimiento {
    public LocalDate fecha;
    public Oficina origen;
    public Oficina destino;
    public String documento;

    public EventoSeguimiento() {
    }

    public EventoSeguimiento(Oficina origen, Oficina destino, String documento) {
        this.origen = origen;
        this.destino = destino;
        this.documento = documento;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }

    public Oficina getOrigen() {
        return origen;
    }

    public void setOrigen(Oficina origen) {
        this.origen = origen;
    }

    public Oficina getDestino() {
        return destino;
    }

    public void setDestino(Oficina destino) {
        this.destino = destino;
    }

    public String getDocumento() {
        return documento;
    }

    public void setDocumento(String documento) {
        this.documento = documento;
    }
    
//    public void movimiento(Expediente expediente, Oficina org, Oficina dest)
//    {
//        org.derivarExpediente(expediente, dest);
//        dest.recibirExpediente(expediente);
//    }

    

    
}
