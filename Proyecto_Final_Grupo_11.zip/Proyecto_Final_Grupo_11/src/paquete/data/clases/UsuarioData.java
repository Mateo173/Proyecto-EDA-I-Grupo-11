package paquete.data.clases;

public class UsuarioData {
    public String usuario;
    public String contrasenia;

    public UsuarioData(String usuario, String contrasenia) {
        this.usuario = usuario;
        this.contrasenia = contrasenia;
    }
    
    
}
