package paquete.data.clases;

import paquete.tdas.Cola;


public class Oficina {
    public String nombre;
    public Cola<Expediente> cola;

    public Oficina() {
        cola = new Cola<>();
    }

    public Oficina(String nombre) {
        this.nombre = nombre;
        cola = new Cola<>();
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
    public void recibirExpediente(Expediente expediente)
    {
        cola.encolar(expediente);
    }
    
    public void derivarExpediente(Expediente expediente, Oficina destino)
    {
        cola.desencolar();
        destino.cola.encolar(expediente);
    }
    
    
}
