package paquete.data.clases;

import java.time.LocalDate;
import paquete.data.admin.EventoSeguimiento;
import paquete.tdas.ListaSimpleEnlazada;

public class Expediente {
    public String exp_id;
    public String prioridad;
    public Interesado interesado;
    public String asunto;
    public ListaSimpleEnlazada<EventoSeguimiento> eventos;
    public LocalDate fechaInicio;
    public LocalDate fechaFin;
    public ListaSimpleEnlazada<String> documentos;
    public String estado;
    public Oficina ubicacionActual;

    public Expediente() {
        eventos = new ListaSimpleEnlazada<>();
        documentos = new ListaSimpleEnlazada<>();
        estado = "En tramite";
    }

    public Expediente(String exp_id, String prioridad, Interesado interesado, String asunto) {
        this.exp_id = exp_id;
        this.prioridad = prioridad;
        this.interesado = interesado;
        this.asunto = asunto;
        this.fechaFin = null;
        eventos = new ListaSimpleEnlazada<>();
        documentos = new ListaSimpleEnlazada<>();
        this.estado = "En tramite";
        this.ubicacionActual = ubicacionActual;
    }

    public Oficina getUbicacionActual() {
        return ubicacionActual;
    }

    public void setUbicacionActual(Oficina ubicacionActual) {
        this.ubicacionActual = ubicacionActual;
    }

    

   
    public String getExp_id() {
        return exp_id;
    }

    public void setExp_id(String exp_id) {
        this.exp_id = exp_id;
    }

    public String getPrioridad() {
        return prioridad;
    }
    
    public String getEstado()
    {
        return estado;
    }
    
    public void setEstado(String estado) {
        this.estado = estado;
    }
    
    public void setPrioridad(String prioridad) {
        this.prioridad = prioridad;
    }

    public Interesado getInteresado() {
        return interesado;
    }

    public void setInteresado(Interesado interesado) {
        this.interesado = interesado;
    }

    public String getAsunto() {
        return asunto;
    }

    public void setAsunto(String asunto) {
        this.asunto = asunto;
    }

    public ListaSimpleEnlazada<EventoSeguimiento> getEventos() {
        return eventos;
    }

    public void setEventos(ListaSimpleEnlazada<EventoSeguimiento> eventos) {
        this.eventos = eventos;
    }

    public LocalDate getFechaInicio() {
        return fechaInicio;
    }

    public void setFechaInicio(LocalDate fechaInicio) {
        this.fechaInicio = fechaInicio;
    }

    public LocalDate getFechaFin() {
        return fechaFin;
    }

    public void setFechaFin(LocalDate fechaFin) {
        this.fechaFin = fechaFin;
    }

    public ListaSimpleEnlazada<String> getDocumentos() {
        return documentos;
    }

    public void setDocumentos(ListaSimpleEnlazada<String> documentos) {
        this.documentos = documentos;
    }

    
    
    public void inicioTramite()
    {
        this.setFechaInicio(LocalDate.now());
    }
    
    public void agregarDoc(String doc)
    {
        documentos.agregar(doc);
    }
    
    public void finalizarTramite()
    {
        this.setFechaFin(LocalDate.now());
    }
    
    public void sinFecha()
    {
        if (this.fechaFin == null)
        {
            LocalDate sinFecha = LocalDate.of(0000,1,01);
            this.setFechaFin(sinFecha);
        }
    }
    
    
    
    
}
